import { useState } from 'react';
import { motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import PlatformSelector from '@/components/PlatformSelector';
import DownloadActions from '@/components/DownloadActions';
import ContactForm from '@/components/ContactForm';

export default function Download() {
  const [selectedPlatform, setSelectedPlatform] = useState<string>('PC');
  const [showContactForm, setShowContactForm] = useState(false);

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />
      
      <div className="pt-24 px-8 pb-12 max-w-7xl mx-auto">
        <motion.h1 
          className="text-4xl font-serif text-gold-500 mb-12 text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          下载/购买
        </motion.h1>

        {/* 平台选择器 */}
        <PlatformSelector 
          selectedPlatform={selectedPlatform}
          onSelect={setSelectedPlatform}
        />

        {/* 下载/购买操作区 */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mt-12"
        >
          <DownloadActions platform={selectedPlatform} />
          
          {/* 联系客服按钮 */}
          <div className="mt-8 text-center">
            <motion.button
              onClick={() => setShowContactForm(true)}
              className="px-6 py-3 border border-gold-500/50 rounded-lg text-gold-500 hover:bg-gold-500/10 transition-colors"
              whileHover={{ 
                boxShadow: '0 0 15px rgba(255, 215, 0, 0.3)',
                scale: 1.05
              }}
            >
              <i className="fa-solid fa-headset mr-2"></i>
              联系客服
            </motion.button>
          </div>
        </motion.div>
      </div>

      {/* 联系客服表单 */}
      <ContactForm 
        isOpen={showContactForm}
        onClose={() => setShowContactForm(false)}
      />
    </div>
  );
}