import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import VideoBackground from '@/components/VideoBackground';
import GameCard from '@/components/GameCard';

// Mock数据
const featuredGames = [
  {
    id: 1,
    title: '山海经异兽录',
    cover: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E5%B1%B1%E6%B5%B7%E7%BB%8F%E5%BC%82%E5%85%BD%E6%B8%B8%E6%88%8F%E5%B0%81%E9%9D%A2&sign=fe756b5a55f7a1e85a3e4960acf964b9',
    description: '基于中国上古神话的开放世界冒险游戏'
  },
  {
    id: 2,
    title: '封神演义',
    cover: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E5%B0%81%E7%A5%9E%E6%BC%94%E4%B9%89%E6%B8%B8%E6%88%8F%E5%B0%81%E9%9D%A2&sign=bf0ed27f63a75cc1ffa1f3ba129b14d0',
    description: '策略卡牌游戏，重现封神大战'
  },
  {
    id: 3,
    title: '白蛇传说',
    cover: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E7%99%BD%E8%9B%87%E4%BC%A0%E6%B8%B8%E6%88%8F%E5%B0%81%E9%9D%A2&sign=e931087273439a2253f1a1df8749d5c9',
    description: '唯美画风的叙事驱动冒险游戏'
  }
];

const videoUrl = 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E4%B8%AD%E5%9B%BD%E7%A5%9E%E8%AF%9D%E6%B8%B8%E6%88%8F%E5%AE%A3%E4%BC%A0%E7%89%87&sign=5011df26fd1d92983e8cb4fa1fc53c8a';

export default function Home() {
  const [isMuted, setIsMuted] = useState(true);
  const videoRef = useRef<HTMLVideoElement>(null);

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  return (
    <div className="relative h-screen overflow-hidden bg-black">
      {/* 视频背景 */}
      <VideoBackground 
        videoUrl={videoUrl} 
        isMuted={isMuted} 
        toggleMute={toggleMute}
        videoRef={videoRef}
      />

      {/* 固定导航栏 */}
      <Navbar />

      {/* 内容区域 */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5 }}
        className="absolute inset-0 flex flex-col items-center justify-center p-8 backdrop-blur-sm bg-black/30"
      >
        <motion.h1 
          initial={{ y: -50 }}
          animate={{ y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-5xl font-bold mb-12 text-gold-500 font-serif"
        >
          神话游戏工作室
        </motion.h1>

        {/* 作品展示区 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl w-full">
          {featuredGames.map((game) => (
            <GameCard key={game.id} game={game} />
          ))}
        </div>
      </motion.div>
    </div>
  );
}