import { motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import { teamMembers, timelineEvents } from '@/data/team';

export default function Team() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />
      
      <div className="pt-24 px-8 pb-12 max-w-7xl mx-auto">
        {/* 标题 */}
        <motion.h1 
          className="text-4xl font-serif text-gold-500 mb-12 text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          团队介绍
        </motion.h1>
        
        {/* 团队成员展示 */}
        <div className="mb-16">
          <h2 className="text-2xl font-serif text-gold-500 mb-8 text-center">核心成员</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {teamMembers.map((member) => (
              <motion.div
                key={member.id}
                className="bg-black/50 backdrop-blur-md rounded-xl border border-gold-500/20 p-6"
                whileHover={{ y: -5, boxShadow: '0 10px 25px rgba(255, 215, 0, 0.2)' }}
              >
                <div className="flex flex-col items-center">
                  <img 
                    src={member.avatar} 
                    alt={member.name}
                    className="w-24 h-24 rounded-full object-cover border-2 border-gold-500 mb-4"
                  />
                  <h3 className="text-xl font-serif text-gold-500">{member.name}</h3>
                  <p className="text-white/80 font-sans mb-2">{member.position}</p>
                  <p className="text-white/60 font-sans text-sm text-center">{member.bio}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* 时间轴 */}
        <div>
          <h2 className="text-2xl font-serif text-gold-500 mb-8 text-center">创作历程</h2>
          <div className="relative">
            {/* 时间轴线条 */}
            <div className="absolute left-1/2 h-full w-px bg-gold-500/30 transform -translate-x-1/2"></div>
            
            {/* 时间轴节点 */}
            <div className="space-y-8">
              {timelineEvents.map((event, index) => (
                <motion.div 
                  key={event.id}
                  className="relative"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  {/* 时间轴节点图标 */}
                  <div className={`absolute left-1/2 w-6 h-6 rounded-full transform -translate-x-1/2 -translate-y-1/2 top-1/2 
                    ${event.isImportant ? 'bg-gold-500 shadow-gold' : 'bg-white/20'}`}>
                    {event.isImportant && (
                      <motion.div
                        className="absolute inset-0 rounded-full bg-gold-500/20"
                        animate={{ 
                          scale: [1, 1.5, 1],
                          opacity: [0.7, 0]
                        }}
                        transition={{ 
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      />
                    )}
                  </div>
                  
                  {/* 时间轴内容 */}
                  <motion.div 
                    className={`w-full md:w-5/12 p-6 rounded-lg border ${event.isImportant ? 'border-gold-500/40 bg-gold-500/10' : 'border-white/10 bg-black/30'} backdrop-blur-sm
                      ${index % 2 === 0 ? 'ml-auto' : 'mr-auto'}`}
                    whileHover={{ scale: 1.02 }}
                  >
                    <div className="flex items-center mb-2">
                      <span className={`text-sm font-sans ${event.isImportant ? 'text-gold-500' : 'text-white/70'}`}>
                        {event.date}
                      </span>
                      {event.isImportant && (
                        <i className="fa-solid fa-star text-gold-500 ml-2"></i>
                      )}
                    </div>
                    <h3 className="text-lg font-serif text-white mb-2">{event.title}</h3>
                    <p className="text-white/70 font-sans text-sm">{event.description}</p>
                  </motion.div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}