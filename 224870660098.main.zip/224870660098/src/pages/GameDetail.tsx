import Navbar from '@/components/Navbar';
import { useParams } from 'react-router-dom';

export default function GameDetail() {
  const { id } = useParams();
  
  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />
      <div className="pt-24 px-8">
        <h1 className="text-4xl font-serif text-gold-500 mb-8">游戏详情 - {id}</h1>
        <p className="font-sans">正在建设中...</p>
      </div>
    </div>
  );
}