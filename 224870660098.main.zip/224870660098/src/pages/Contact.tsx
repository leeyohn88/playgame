import Navbar from '@/components/Navbar';

export default function Contact() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />
      <div className="pt-24 px-8">
        <h1 className="text-4xl font-serif text-gold-500 mb-8">联系我们</h1>
        <p className="font-sans">正在建设中...</p>
      </div>
    </div>
  );
}