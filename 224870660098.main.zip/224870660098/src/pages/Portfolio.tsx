import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from '@/components/Navbar';
import GameCard from '@/components/GameCard';
import GameFilter from '@/components/GameFilter';
import GameModal from '@/components/GameModal';
import { games } from '@/data/games';

export default function Portfolio() {
  const [activeCategory, setActiveCategory] = useState('');
  const [selectedGame, setSelectedGame] = useState<typeof games[0] | null>(null);

  const filteredGames = activeCategory 
    ? games.filter(game => game.category === activeCategory) 
    : games;

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />
      
      <div className="pt-24 px-8 pb-12 max-w-7xl mx-auto">
        <motion.h1 
          className="text-4xl font-serif text-gold-500 mb-8 text-center"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          作品集
        </motion.h1>

        {/* 分类筛选 */}
        <GameFilter 
          activeCategory={activeCategory} 
          setActiveCategory={setActiveCategory} 
        />

        {/* 游戏网格 */}
        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
          layout
        >
          <AnimatePresence>
            {filteredGames.map((game) => (
              <motion.div
                key={game.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
              >
                <GameCard 
                  game={game} 
                  onClick={() => setSelectedGame(game)}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* 详情弹窗 */}
      <GameModal 
        selectedGame={selectedGame} 
        onClose={() => setSelectedGame(null)} 
      />
    </div>
  );
}
