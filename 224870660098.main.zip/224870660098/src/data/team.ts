export interface TeamMember {
  id: number;
  name: string;
  avatar: string;
  position: string;
  bio: string;
}

export interface TimelineEvent {
  id: number;
  date: string;
  title: string;
  description: string;
  isImportant: boolean;
}

export const teamMembers: TeamMember[] = [
  {
    id: 1,
    name: '李月恩',
    avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%A0%BC%E6%B8%B8%E6%88%8F%E5%BC%80%E5%8F%91%E8%80%85%E5%A4%B4%E5%83%8F&sign=03f2efe2c8e7c6d876f2734957266cfb',
    position: '创意总监',
    bio: '上海美术职业学院教授，神话游戏设计专家'
  },
  {
    id: 2,
    name: '张云',
    avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%A0%BC%E6%B8%B8%E6%88%8F%E7%BE%8E%E6%9C%AF%E8%AE%BE%E8%AE%A1%E5%B8%88%E5%A4%B4%E5%83%8F&sign=f0863b2f340ecb53cbbab100c92e0d75',
    position: '美术指导',
    bio: '擅长中国传统水墨风格设计'
  },
  {
    id: 3,
    name: '王雷',
    avatar: 'https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=%E4%B8%AD%E5%9B%BD%E9%A3%8E%E6%A0%BC%E6%B8%B8%E6%88%8F%E7%A8%8B%E5%BA%8F%E5%91%98%E5%A4%B4%E5%83%8F&sign=a0ee3625b7d1fc1c053958f50e5cb1f5',
    position: '技术主管',
    bio: '游戏引擎开发专家'
  }
];

export const timelineEvents: TimelineEvent[] = [
  {
    id: 1,
    date: '2020.03',
    title: '团队成立',
    description: '在上海美术职业学院成立神话游戏工作室',
    isImportant: true
  },
  {
    id: 2,
    date: '2021.01',
    title: '首款游戏发布',
    description: '发布第一款神话题材独立游戏《山海经异兽录》',
    isImportant: true
  },
  {
    id: 3,
    date: '2021.09',
    title: '商业合作',
    description: '与腾讯游戏达成战略合作',
    isImportant: false
  },
  {
    id: 4,
    date: '2022.06',
    title: '学生培养计划',
    description: '启动游戏设计人才培养项目',
    isImportant: false
  },
  {
    id: 5,
    date: '2023.01',
    title: '国际奖项',
    description: '《封神演义》获得国际游戏设计金奖',
    isImportant: true
  }
];