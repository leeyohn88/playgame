export interface Game {
  id: number;
  title: string;
  category: '独立游戏' | '商业项目' | '学生作品';
  cover: string;
  screenshots: string[];
  videoUrl: string;
  description: string;
}

export const games: Game[] = [
  {
    id: 1,
    title: '山海经异兽录',
    category: '商业项目',
    cover: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E5%B1%B1%E6%B5%B7%E7%BB%8F%E5%BC%82%E5%85%BD%E6%B8%B8%E6%88%8F%E5%B0%81%E9%9D%A2&sign=fe756b5a55f7a1e85a3e4960acf964b9',
    screenshots: [
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E5%B1%B1%E6%B5%B7%E7%BB%8F%E6%B8%B8%E6%88%8F%E6%88%AA%E5%9B%BE1&sign=8eede9250169a34b1a47d375cc9b8cae',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E5%B1%B1%E6%B5%B7%E7%BB%8F%E6%B8%B8%E6%88%8F%E6%88%AA%E5%9B%BE2&sign=3e095eb05c5f98bb3e7471cdda44e7ef'
    ],
    videoUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E5%B1%B1%E6%B5%B7%E7%BB%8F%E6%B8%B8%E6%88%8F%E5%AE%A3%E4%BC%A0%E7%89%87&sign=19d9c7473483d6206cf9866fead3fa27',
    description: '基于中国上古神话的开放世界冒险游戏'
  },
  {
    id: 2,
    title: '封神演义',
    category: '商业项目',
    cover: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E5%B0%81%E7%A5%9E%E6%BC%94%E4%B9%89%E6%B8%B8%E6%88%8F%E5%B0%81%E9%9D%A2&sign=bf0ed27f63a75cc1ffa1f3ba129b14d0',
    screenshots: [
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E5%B0%81%E7%A5%9E%E6%BC%94%E4%B9%89%E6%B8%B8%E6%88%8F%E6%88%AA%E5%9B%BE1&sign=46db4200ef14b3c71fcf502b520194a3',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E5%B0%81%E7%A5%9E%E6%BC%94%E4%B9%89%E6%B8%B8%E6%88%8F%E6%88%AA%E5%9B%BE2&sign=f1fbe1aeafc47ba94d1cb984f7ec6d43'
    ],
    videoUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E5%B0%81%E7%A5%9E%E6%BC%94%E4%B9%89%E6%B8%B8%E6%88%8F%E5%AE%A3%E4%BC%A0%E7%89%87&sign=3810b6a0428ad07e16cbfcdcb49d3f97',
    description: '策略卡牌游戏，重现封神大战'
  },
  {
    id: 3,
    title: '白蛇传说',
    category: '独立游戏',
    cover: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E7%99%BD%E8%9B%87%E4%BC%A0%E6%B8%B8%E6%88%8F%E5%B0%81%E9%9D%A2&sign=e931087273439a2253f1a1df8749d5c9',
    screenshots: [
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E7%99%BD%E8%9B%87%E4%BC%A0%E6%B8%B8%E6%88%8F%E6%88%AA%E5%9B%BE1&sign=44b377ac9fc691ec4e4aa63b6b4c8153',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E7%99%BD%E8%9B%87%E4%BC%A0%E6%B8%B8%E6%88%8F%E6%88%AA%E5%9B%BE2&sign=1ffc7e8b4a1dbbc596f80ed00643c904'
    ],
    videoUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E7%99%BD%E8%9B%87%E4%BC%A0%E6%B8%B8%E6%88%8F%E5%AE%A3%E4%BC%A0%E7%89%87&sign=17c432b0fe208c16213bb09effb5e1d0',
    description: '唯美画风的叙事驱动冒险游戏'
  },
  {
    id: 4,
    title: '西游记',
    category: '学生作品',
    cover: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E8%A5%BF%E6%B8%B8%E8%AE%B0%E6%B8%B8%E6%88%8F%E5%B0%81%E9%9D%A2&sign=cd35e720382c8f635d5ce010bb5e7e81',
    screenshots: [
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E8%A5%BF%E6%B8%B8%E8%AE%B0%E6%B8%B8%E6%88%8F%E6%88%AA%E5%9B%BE1&sign=8a73ebbd8884b84f50af671f07c84afd',
      'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E8%A5%BF%E6%B8%B8%E8%AE%B0%E6%B8%B8%E6%88%8F%E6%88%AA%E5%9B%BE2&sign=76f05fcc685d449a1ae85bed60a93539'
    ],
    videoUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=%E8%A5%BF%E6%B8%B8%E8%AE%B0%E6%B8%B8%E6%88%8F%E5%AE%A3%E4%BC%A0%E7%89%87&sign=1d9a0f8b084db07158b470b1d0b81003',
    description: '基于西游记改编的横版动作游戏'
  }
];
