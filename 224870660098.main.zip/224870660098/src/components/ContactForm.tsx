import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';

interface ContactFormProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ContactForm({ isOpen, onClose }: ContactFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // 这里可以添加表单提交逻辑
    alert('客服请求已提交，我们会尽快与您联系！');
    onClose();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div 
            className="relative w-full max-w-md bg-black rounded-xl overflow-hidden border border-gold-500/30"
            initial={{ scale: 0.9, y: 50 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 50 }}
            transition={{ type: 'spring', damping: 25 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* 关闭按钮 */}
            <button 
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/50 text-white hover:bg-gold-500/20 transition-colors"
              onClick={onClose}
            >
              <i className="fa-solid fa-xmark"></i>
            </button>

            {/* 表单内容 */}
            <div className="p-8">
              <h2 className="text-2xl font-serif text-gold-500 mb-6 text-center">联系客服</h2>
              
              <form onSubmit={handleSubmit}>
                <div className="space-y-4">
                  <div>
                    <label className="block text-white/70 font-sans mb-2">姓名</label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-2 bg-black/50 border border-white/20 rounded-lg text-white focus:border-gold-500 focus:outline-none"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-white/70 font-sans mb-2">邮箱</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-2 bg-black/50 border border-white/20 rounded-lg text-white focus:border-gold-500 focus:outline-none"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-white/70 font-sans mb-2">问题描述</label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      rows={4}
                      className="w-full px-4 py-2 bg-black/50 border border-white/20 rounded-lg text-white focus:border-gold-500 focus:outline-none"
                      required
                    />
                  </div>
                </div>
                
                <motion.button
                  type="submit"
                  className="w-full mt-6 px-6 py-3 bg-gold-500 text-black rounded-lg font-serif hover:bg-gold-400 transition-colors"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  提交
                </motion.button>
              </form>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}