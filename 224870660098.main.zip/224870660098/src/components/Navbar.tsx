import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const navItems = [
  { name: '作品集', path: '/portfolio' },
  { name: '团队', path: '/team' },
  { name: '下载', path: '/download' },
  { name: '联系我们', path: '/contact' }
];

export default function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 p-4 bg-black/80 backdrop-blur-md border-b border-gold-500/20">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-xl font-serif text-gold-500"
        >
          神话游戏
        </motion.div>

        <ul className="flex space-x-8">
          {navItems.map((item) => (
            <motion.li 
              key={item.name}
              whileHover={{ 
                scale: 1.05,
                textShadow: '0 0 8px rgba(255, 215, 0, 0.7)'
              }}
              className="relative"
            >
              <Link 
                to={item.path} 
                className="text-white font-sans hover:text-gold-500 transition-colors duration-300"
              >
                {item.name}
                <motion.span 
                  className="absolute bottom-0 left-0 w-0 h-px bg-gold-500"
                  whileHover={{ width: '100%' }}
                  transition={{ duration: 0.3 }}
                />
              </Link>
            </motion.li>
          ))}
        </ul>
      </div>
    </nav>
  );
}