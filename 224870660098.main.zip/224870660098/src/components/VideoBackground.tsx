import { motion } from 'framer-motion';
import { useState } from 'react';

interface VideoBackgroundProps {
  videoUrl: string;
  isMuted: boolean;
  toggleMute: () => void;
  videoRef: React.RefObject<HTMLVideoElement>;
}

export default function VideoBackground({ 
  videoUrl, 
  isMuted, 
  toggleMute,
  videoRef
}: VideoBackgroundProps) {
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(err => {
        console.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
        setIsFullscreen(false);
      }
    }
  };

  return (
    <div className="absolute inset-0 overflow-hidden">
      <video
        ref={videoRef}
        autoPlay
        loop
        muted={isMuted}
        className="w-full h-full object-cover"
      >
        <source src={videoUrl} type="video/mp4" />
      </video>

      {/* 视频控制按钮 */}
      <div className="absolute bottom-4 right-4 flex space-x-4 z-10">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={toggleMute}
          className="p-2 rounded-full bg-black/50 text-white"
        >
          {isMuted ? (
            <i className="fa-solid fa-volume-xmark"></i>
          ) : (
            <i className="fa-solid fa-volume-high"></i>
          )}
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={toggleFullscreen}
          className="p-2 rounded-full bg-black/50 text-white"
        >
          {isFullscreen ? (
            <i className="fa-solid fa-compress"></i>
          ) : (
            <i className="fa-solid fa-expand"></i>
          )}
        </motion.button>
      </div>
    </div>
  );
}