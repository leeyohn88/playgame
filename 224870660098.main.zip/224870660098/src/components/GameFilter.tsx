import { motion } from 'framer-motion';
import { useState } from 'react';

interface GameFilterProps {
  activeCategory: string;
  setActiveCategory: (category: string) => void;
}

const categories = ['全部', '独立游戏', '商业项目', '学生作品'];

export default function GameFilter({ 
  activeCategory, 
  setActiveCategory 
}: GameFilterProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <div className="flex justify-center mb-12">
      <div className="relative flex space-x-1 bg-black/30 backdrop-blur-md p-1 rounded-lg border border-gold-500/20">
        {categories.map((category, index) => (
          <motion.button
            key={category}
            className={`relative px-6 py-2 text-sm font-sans rounded-md z-10 ${
              activeCategory === category 
                ? 'text-black' 
                : 'text-white hover:text-gold-500'
            }`}
            onClick={() => setActiveCategory(category === '全部' ? '' : category)}
            onHoverStart={() => setHoveredIndex(index)}
            onHoverEnd={() => setHoveredIndex(null)}
          >
            {category}
            {activeCategory === category && (
              <motion.span
                className="absolute inset-0 bg-gold-500 rounded-md z-[-1]"
                layoutId="activeFilter"
                transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
              />
            )}
          </motion.button>
        ))}
        
        {/* 水墨背景效果 */}
        <motion.div 
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0"
          animate={{ 
            opacity: hoveredIndex !== null ? 0.3 : 0,
            x: ['-100%', '100%'],
          }}
          transition={{ 
            duration: 1.5,
            repeat: Infinity
          }}
        />
      </div>
    </div>
  );
}
