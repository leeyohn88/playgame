import { motion } from 'framer-motion';

interface DownloadOption {
  id: string;
  name: string;
  type: 'download' | 'purchase';
  url?: string;
  price?: string;
  icon: string;
}

const platformOptions: Record<string, DownloadOption[]> = {
  PC: [
    {
      id: 'steam',
      name: 'Steam',
      type: 'purchase',
      price: '¥68',
      icon: 'fa-brands fa-steam'
    },
    {
      id: 'direct',
      name: '直接下载',
      type: 'download',
      url: '#',
      icon: 'fa-solid fa-download'
    }
  ],
  Mobile: [
    {
      id: 'appstore',
      name: 'App Store',
      type: 'download',
      url: '#',
      icon: 'fa-brands fa-app-store'
    },
    {
      id: 'playstore',
      name: 'Google Play',
      type: 'download',
      url: '#',
      icon: 'fa-brands fa-google-play'
    }
  ],
  Console: []
};

interface DownloadActionsProps {
  platform: string;
}

export default function DownloadActions({ platform }: DownloadActionsProps) {
  const options = platformOptions[platform] || [];

  return (
    <div className="bg-black/30 backdrop-blur-md rounded-xl border border-gold-500/20 p-6">
      <h2 className="text-xl font-serif text-gold-500 mb-6 text-center">获取方式</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {options.length > 0 ? (
          options.map((option) => (
            <motion.div
              key={option.id}
              whileHover={{ 
                y: -3,
                boxShadow: '0 5px 15px rgba(255, 215, 0, 0.3)'
              }}
              transition={{ duration: 0.3 }}
            >
              <a
                href={option.url || '#'}
                className={`block p-4 rounded-lg border ${
                  option.type === 'download' 
                    ? 'border-blue-500/30 hover:bg-blue-500/10' 
                    : 'border-gold-500/30 hover:bg-gold-500/10'
                } transition-colors`}
              >
                <div className="flex items-center">
                  <i className={`${option.icon} mr-3 text-xl ${
                    option.type === 'download' ? 'text-blue-400' : 'text-gold-500'
                  }`}></i>
                  <div>
                    <h3 className="font-serif text-white">{option.name}</h3>
                    <p className="text-sm text-white/70">
                      {option.type === 'download' ? '免费下载' : `售价: ${option.price}`}
                    </p>
                  </div>
                </div>
              </a>
            </motion.div>
          ))
        ) : (
          <div className="col-span-2 text-center py-8 text-white/70">
            <i className="fa-solid fa-hourglass-half text-2xl mb-2"></i>
            <p>该平台版本即将推出，敬请期待</p>
          </div>
        )}
      </div>
    </div>
  );
}