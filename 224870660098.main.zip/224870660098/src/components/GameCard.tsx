import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

interface Game {
  id: number;
  title: string;
  cover: string;
  description: string;
}

interface GameCardProps {
  game: Game;
}
export default function GameCard({ game, onClick }: GameCardProps & { onClick?: () => void }) {
  return (
    <motion.div 
      className="relative overflow-hidden rounded-lg border border-gold-500/30 bg-black/50 backdrop-blur-md h-80 cursor-pointer"
      whileHover={{ 
        y: -10,
        boxShadow: '0 10px 25px rgba(255, 215, 0, 0.3)'
      }}
      transition={{ duration: 0.3 }}
      onClick={onClick}
    >
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent z-10" />
      
      <img 
        src={game.cover} 
        alt={game.title}
        className="w-full h-full object-cover"
      />

      <div className="absolute bottom-0 left-0 right-0 p-4 z-20">
        <motion.h3 
          className="text-xl font-bold text-gold-500 font-serif mb-2"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
        >
          {game.title}
        </motion.h3>
        <p className="text-white font-sans text-sm">
          {game.description}
        </p>
        <div className="mt-2">
          <span className="inline-block px-2 py-1 text-xs bg-gold-500/20 text-gold-500 rounded-full">
            {game.category}
          </span>
        </div>
      </div>

      {/* 水墨动画效果 */}
      <motion.div 
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0"
        whileHover={{ 
          opacity: 0.3,
          x: ['-100%', '100%'],
        }}
        transition={{ 
          duration: 1.5,
          repeat: Infinity
        }}
      />
    </motion.div>
  );
}
