import { motion } from 'framer-motion';

interface Platform {
  id: string;
  name: string;
  icon: string;
  available: boolean;
}

const platforms: Platform[] = [
  {
    id: 'PC',
    name: 'PC',
    icon: 'fa-solid fa-desktop',
    available: true
  },
  {
    id: 'Mobile',
    name: '移动端',
    icon: 'fa-solid fa-mobile-screen',
    available: true
  },
  {
    id: 'Console',
    name: '主机',
    icon: 'fa-solid fa-gamepad',
    available: false
  }
];

interface PlatformSelectorProps {
  selectedPlatform: string;
  onSelect: (platform: string) => void;
}

export default function PlatformSelector({ 
  selectedPlatform, 
  onSelect 
}: PlatformSelectorProps) {
  return (
    <div className="bg-black/30 backdrop-blur-md rounded-xl border border-gold-500/20 p-6">
      <h2 className="text-xl font-serif text-gold-500 mb-6 text-center">选择平台</h2>
      
      <div className="flex justify-center space-x-4">
        {platforms.map((platform) => (
          <motion.button
            key={platform.id}
            onClick={() => platform.available && onSelect(platform.id)}
            className={`relative px-6 py-3 rounded-lg border ${
              selectedPlatform === platform.id 
                ? 'border-gold-500 bg-gold-500/10 text-gold-500' 
                : 'border-white/20 text-white/70'
            } ${
              !platform.available ? 'opacity-50 cursor-not-allowed' : 'hover:border-gold-500/50'
            }`}
            whileHover={platform.available ? { 
              y: -3,
              boxShadow: '0 5px 15px rgba(255, 215, 0, 0.2)'
            } : {}}
            transition={{ duration: 0.3 }}
          >
            <i className={`${platform.icon} mr-2`}></i>
            {platform.name}
            {!platform.available && (
              <span className="absolute -top-2 -right-2 text-xs bg-red-500 text-white px-2 py-1 rounded-full">
                即将推出
              </span>
            )}
            
            {/* 水墨动画效果 */}
            {selectedPlatform === platform.id && platform.available && (
              <motion.div 
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0"
                animate={{ 
                  opacity: 0.3,
                  x: ['-100%', '100%'],
                }}
                transition={{ 
                  duration: 1.5,
                  repeat: Infinity
                }}
              />
            )}
          </motion.button>
        ))}
      </div>
    </div>
  );
}