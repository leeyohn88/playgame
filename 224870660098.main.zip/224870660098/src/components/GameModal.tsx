import { motion, AnimatePresence } from 'framer-motion';
import { Game } from '@/data/games';
import { Link } from 'react-router-dom';

interface GameModalProps {
  selectedGame: Game | null;
  onClose: () => void;
}

export default function GameModal({ selectedGame, onClose }: GameModalProps) {
  return (
    <AnimatePresence>
      {selectedGame && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div 
            className="relative w-full max-w-4xl bg-black rounded-xl overflow-hidden border border-gold-500/30"
            initial={{ scale: 0.9, y: 50 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 50 }}
            transition={{ type: 'spring', damping: 25 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* 关闭按钮 */}
            <button 
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/50 text-white hover:bg-gold-500/20 transition-colors"
              onClick={onClose}
            >
              <i className="fa-solid fa-xmark"></i>
            </button>

            {/* 内容区域 */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 h-full">
              {/* 媒体区域 */}
              <div className="relative h-64 lg:h-full">
                <video
                  className="w-full h-full object-cover"
                  autoPlay
                  loop
                  muted
                  src={selectedGame.videoUrl}
                />
                
                {/* 截图预览 */}
                <div className="absolute bottom-0 left-0 right-0 p-4 flex space-x-2 overflow-x-auto bg-gradient-to-t from-black/80 to-transparent">
                  {selectedGame.screenshots.map((screenshot, index) => (
                    <div key={index} className="flex-shrink-0 w-16 h-16 rounded overflow-hidden border border-gold-500/30">
                      <img 
                        src={screenshot} 
                        alt={`截图 ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* 文字信息区域 */}
              <div className="p-8 flex flex-col">
                <h2 className="text-2xl font-serif text-gold-500 mb-4">
                  {selectedGame.title}
                </h2>
                <p className="text-white font-sans mb-6">
                  {selectedGame.description}
                </p>
                
                <div className="mt-auto pt-6 border-t border-gold-500/20">
                  <Link 
                    to="/download" 
                    className="inline-flex items-center px-6 py-2 bg-gold-500 text-black rounded-md hover:bg-gold-400 transition-colors"
                  >
                    <i className="fa-solid fa-download mr-2"></i>
                    获取游戏
                  </Link>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
