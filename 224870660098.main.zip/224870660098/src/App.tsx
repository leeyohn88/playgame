import { Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";
import { createContext, useState } from "react";
import Portfolio from "@/pages/Portfolio";
import Team from "@/pages/Team";
import Download from "@/pages/Download";
import Contact from "@/pages/Contact";
import GameDetail from "@/pages/GameDetail";

export const AuthContext = createContext({
  isAuthenticated: false,
  setIsAuthenticated: (value: boolean) => {},
  logout: () => {},
});

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, setIsAuthenticated, logout }}
    >
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/portfolio" element={<Portfolio />} />
        <Route path="/team" element={<Team />} />
        <Route path="/download" element={<Download />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/game/:id" element={<GameDetail />} />
      </Routes>
    </AuthContext.Provider>
  );
}
